' Copyright (c) 2026 Roku, Inc.
' SPDX-License-Identifier: MIT

sub Main()
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.setMessagePort(m.port)

    scene = screen.CreateScene("BaseAppScene")
    screen.show()

    while(true)
        msg = wait(0, m.port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        else
            print "Unhandled message type: "; msgType
        end if
    end while
end sub

'//# sourceMappingURL=Main.brs.map